/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.bitpricecalculation;

import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.io.DoubleWritable;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author LiWH
 */
public class PriceReducer extends
        Reducer<Text, DoubleWritable, Text, Text> {

    protected void reduce(Text key, Iterable<DoubleWritable> values,
            Context context) throws IOException, InterruptedException {
        Double max = 0.0;
        Double min = Double.MAX_VALUE;
        Text ex = new Text();

        Iterator<DoubleWritable> iter = values.iterator();
        while (iter.hasNext()) {
            DoubleWritable price = iter.next();

            if (price.get() > max) {
                max = price.get();
            }
            if (price.get() < min) {
                min = price.get();
            }
            //calculate max and min
        }
        ex.set("Min: " + min + " Max: " + max);
        //set min and max
        context.write(key, ex);
        //write min and max
    }
}
