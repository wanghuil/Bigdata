/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.bitpricecalculation;

import au.com.bytecode.opencsv.CSVParser;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.text.SimpleDateFormat;
import org.apache.hadoop.io.DoubleWritable;

/**
 *
 * @author LiWH
 */
public class PriceMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        if (key.get() > 0) {
            String[] lines = new CSVParser().parseLine(value.toString());
            Text time = new Text();
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM");
            time.set(dateFormatter.format(Long.parseLong(lines[0]) * 1000));
            //cast timestamp into yyyy-MM 
            //set longWritablle 

            context.write(time, new DoubleWritable(Double.parseDouble(lines[7])));
            //write time and price
        }
    }
}
