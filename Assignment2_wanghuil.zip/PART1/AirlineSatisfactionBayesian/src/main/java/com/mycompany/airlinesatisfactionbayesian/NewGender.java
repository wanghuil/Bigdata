/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.airlinesatisfactionbayesian;

import org.apache.spark.sql.api.java.UDF1;

/**
 *
 * @author LiWH
 */
public class NewGender implements UDF1<String, Integer>{
    public Integer call(String s) throws Exception {
        int genderCode = 0;
        if (s.equals("Male")) {
            genderCode = 1;
        }
        return genderCode;
    }
}
//male=1, female=2
