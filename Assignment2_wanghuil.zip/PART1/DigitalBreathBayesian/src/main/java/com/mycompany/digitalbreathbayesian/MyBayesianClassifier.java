/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.digitalbreathbayesian;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.classification.NaiveBayes;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.StringIndexerModel;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.feature.VectorIndexer;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import static org.apache.spark.sql.functions.callUDF;
import static org.apache.spark.sql.functions.col;
import org.apache.spark.sql.types.DataTypes;

/**
 *
 * @author LiWH
 */
public class MyBayesianClassifier {

    public static void main(String[] args) {
        SparkSession spark = SparkSession
                .builder()
                .appName("DigitalBreathBayesian")
                .getOrCreate();
        Logger rootLogger = LogManager.getRootLogger();
        rootLogger.setLevel(Level.WARN);

        // Load the data stored in csv format as a DataFrame.
        Dataset<Row> data
                = spark.read().format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat")
                        .option("header", "true")
                        .load("hdfs://spark01.cmua.dom:9000/wanghuil/DigitalBreathTest.txt");
        //hdfs://spark01.cmua.dom:9000/wanghuil/DigitalBreathTestData2014.txt
        data.show();
        //Print spark schema

        UDF1 newGender = (UDF1) new NewGender();
        spark.udf().register("newGender", newGender, DataTypes.IntegerType);
        // To add a new column, convert gender into binary format
        // 0 represents female and 1 represents male
        Dataset<Row> dsnew = data.withColumn("NewGender", callUDF("newGender", col("Gender")));
        // To show the new gender      
        dsnew.show();
        // To convert Gender

        UDF1 newWeekType = (UDF1) new NewWeekType();
        spark.udf().register("newWeekType", newWeekType, DataTypes.IntegerType);
        // To add a new column, convert WeekType into binary
        //0 represents weekends and 1 represents weekdays
        Dataset<Row> dsnew1 = dsnew.withColumn("NewWeekType", callUDF("newWeekType", col("WeekType")));
        // To show the new weekType     
        dsnew1.show();
        // To convert weekType

        // Index labels, adding metadata to the label column.
        // Fit on whole dataset to include all labels in index.
        StringIndexerModel labelIndexer = new StringIndexer()
                .setInputCol("Month")
                .setOutputCol("-Month")
                .fit(dsnew1);
        dsnew1 = labelIndexer.transform(dsnew1);

        StringIndexerModel labelIndexer1 = new StringIndexer()
                .setInputCol("WeekType")
                .setOutputCol("-WeekType")
                .fit(dsnew1);
        dsnew1 = labelIndexer1.transform(dsnew1);

        StringIndexerModel labelIndexer2 = new StringIndexer()
                .setInputCol("TimeBand")
                .setOutputCol("-TimeBand")
                .fit(dsnew1);
        dsnew1 = labelIndexer2.transform(dsnew1);

        StringIndexerModel labelIndexer3 = new StringIndexer()
                .setInputCol("BreathAlcoholLevel(microg 100ml)")
                .setOutputCol("-BreathAlcoholLevel(microg 100ml)")
                .fit(dsnew1);
        dsnew1 = labelIndexer3.transform(dsnew1);

        StringIndexerModel labelIndexer4 = new StringIndexer()
                .setInputCol("Gender")
                .setOutputCol("-Gender")
                .fit(dsnew1);
        dsnew1 = labelIndexer4.transform(dsnew1);

        Dataset<Row> gh = dsnew1.select(
                col("-Month"),
                col("NewWeekType"),
                col("-TimeBand"),
                col("-BreathAlcoholLevel(microg 100ml)"),
                col("NewGender"));
        //forming str array
        String[] featuresCols = gh.columns();

        //This concatenates all feature columns into a single feature vector in a new column "rawFeatures".
        VectorAssembler vectorAssembler = new VectorAssembler().setInputCols(featuresCols).setOutputCol("rawFeatures");

        // Automatically identify categorical features, and index them.
        VectorIndexer featureIndexer = new VectorIndexer()
                .setInputCol("rawFeatures")
                .setOutputCol("features")
                .setMaxCategories(4);
        // features with > 4 distinct values are treated as continuous.

        // Split the data into training and test sets 
        //30% held out for testing and 70% for training 
        Dataset<Row>[] splits = gh.randomSplit(new double[]{0.7, 0.3}, 1234L);
        Dataset<Row> train = splits[0];
        Dataset<Row> test = splits[1];

        // create the trainer and set its parameters
        NaiveBayes nb = new NaiveBayes()
                .setLabelCol("-BreathAlcoholLevel(microg 100ml)")
                //the predict attribute
                .setFeaturesCol("features");

        // Chain indexers and tree in a Pipeline.
        Pipeline pipeline = new Pipeline()
                .setStages(new PipelineStage[]{vectorAssembler, featureIndexer, nb});

        // Train model. Also runs the indexers.
        PipelineModel model = pipeline.fit(train);

        // Make predictions..
        Dataset<Row> predictions = model.transform(test);
        predictions.show();

        // set label, prediction, accuracy
        MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
                .setLabelCol("-BreathAlcoholLevel(microg 100ml)")
                .setPredictionCol("prediction")
                .setMetricName("accuracy");
        double accuracy = evaluator.evaluate(predictions);
        System.out.println("Test Error = " + (1.0 - accuracy));

        spark.stop();
        //stop spark
    }

}
