/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.digitalbreathkmeans;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.clustering.KMeans;
import org.apache.spark.ml.clustering.KMeansModel;
import org.apache.spark.ml.evaluation.ClusteringEvaluator;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.StringIndexerModel;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.feature.VectorIndexer;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import static org.apache.spark.sql.functions.col;
/**
 *
 * @author LiWH
 */
public class MyKmeansCluster {
     public static void main(String[] args) {
    SparkSession spark = SparkSession
      .builder()
      .appName("DigitalBreathKMeans")
      .getOrCreate();

    // $example on$
    // Loads data.
    Dataset<Row> dataset = spark.read().format("org.apache.spark.sql.execution.datasources.csv.CSVFileFormat")
            .option("header", "true")
            .load("hdfs://spark01.cmua.dom:9000/wanghuil/DigitalBreathTest.txt");
    //hdfs://spark01.cmua.dom:9000/wanghuil/DigitalBreathTestData2014.txt
                 
    dataset.show();
    
    
    Dataset<Row> dformatted = dataset.select(
                col("Month"),
                col("WeekType"),
                col("TimeBand"),
                col("BreathAlcoholLevel(microg 100ml)"),
                col("Gender"));
        dformatted.printSchema();

        StringIndexerModel labelIndexer = new StringIndexer()
                .setInputCol("Month")
                .setOutputCol("-Month")
                .fit(dataset);
        dformatted = labelIndexer.transform(dformatted);

        StringIndexerModel labelIndexer1 = new StringIndexer()
                .setInputCol("WeekType")
                .setOutputCol("-WeekType")
                .fit(dataset);
        dformatted = labelIndexer1.transform(dformatted);

        StringIndexerModel labelIndexer2 = new StringIndexer()
                .setInputCol("TimeBand")
                .setOutputCol("-TimeBand")
                .fit(dataset);
        dformatted = labelIndexer2.transform(dformatted);

        StringIndexerModel labelIndexer3 = new StringIndexer()
                .setInputCol("BreathAlcoholLevel(microg 100ml)")
                .setOutputCol("-BreathAlcoholLevel(microg 100ml)")
                .fit(dataset);
        dformatted = labelIndexer3.transform(dformatted);

        StringIndexerModel labelIndexer4 = new StringIndexer()
                .setInputCol("Gender")
                .setOutputCol("-Gender")
                .fit(dataset);
        dformatted = labelIndexer4.transform(dformatted);

        Dataset<Row> gh = dformatted.select(
                col("-Month"),
                col("-WeekType"),
                col("-TimeBand"),
                col("-BreathAlcoholLevel(microg 100ml)"),
                col("-Gender"));
        //forming str array
        String[] featuresCols = gh.columns();
        //This concatenates all feature columns into a single feature vector in a new column "rawFeatures".
        VectorAssembler vectorAssembler = new VectorAssembler().setInputCols(featuresCols).setOutputCol("rawFeatures");

        VectorIndexer featureIndexer = new VectorIndexer()
                .setInputCol("rawFeatures")
                .setOutputCol("features")
                .setMaxCategories(4); // features with > 4 distinct values are treated as continuous.

        //create pipeline   
        Pipeline pipeline = new Pipeline()
                .setStages(new PipelineStage[]{vectorAssembler, featureIndexer});

        // Train model. This also runs the indexers.
        PipelineModel model = pipeline.fit(dformatted);

        //data process
        Dataset<Row> predictions = model.transform(dformatted);
        
    // Trains a k-means model.
    KMeans kmeans = new org.apache.spark.ml.clustering.KMeans().setK(4).setSeed(1L);
    
    KMeansModel model1 = kmeans.fit(predictions);

    Dataset<Row> result = model1.transform(predictions);
    // Evaluate clustering by computing Silhouette score
    ClusteringEvaluator evaluator = new ClusteringEvaluator();

    double silhouette = evaluator.evaluate(result);
    System.out.println("Silhouette with squared euclidean distance = " + silhouette);

    // Shows the result.
    org.apache.spark.ml.linalg.Vector[] centers;
         centers = model1.clusterCenters();
     System.out.println("Cluster Centers: ");
     for (org.apache.spark.ml.linalg.Vector center: centers) {
     System.out.println(center);
}



    spark.stop();
     }
}
